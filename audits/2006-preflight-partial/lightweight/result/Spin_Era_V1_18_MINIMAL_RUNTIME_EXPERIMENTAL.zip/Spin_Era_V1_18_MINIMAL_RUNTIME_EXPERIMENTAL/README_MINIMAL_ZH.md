# V1.18 最小运行包｜EXPERIMENTAL

这是已有V1.18源码的可逆分发实验，不是2004—2006新历史整合版，也不是替代全量史料的正式存档。新的完整历史ZIP超过输入读取限额，尚未读取其MASTER_PROMPT、SOURCE_MANIFEST和2005—2006原始比赛。本包的唯一预置生涯起点仍是2005-01-01；不能将它冒充2006年末恢复点。

Python3.11+，仅标准库。先运行：

```bash
python verify_package.py
```

恢复已有起点：

```python
from simulator import WorldSession
w=WorldSession.load_file('examples/v1_18_opening/START_WORLD_V1_18.json')
assert w.consistency_check(deep=True)['valid']
print(w.card(w.data['main_player_id']))
```

不要自动运行正式比赛，尤其不得擅自运行2007年赛事。预置起点2004赛果23场，只读保留，不重抽。

所有规则指纹文件及所需模块均与原V1.18字节一致，永久数值、随机调用和比赛算法没有改动。本实验只移除非运行必需的大型旧报告、重复演示、训练曲线、原始史料和全量审计证据；这些材料仍需保存在原完整包。删减清单逐项保留源路径、大小和SHA256。

本包保留一些历史迁移/构建Python文件作为冻结依赖或源码参考；由于原始史料和测试夹具不随本包分发，迁移、旧打包脚本和完整self_test.py不可在此独立运行，不把它们列为验收通过。若要重建2004迁移或写依据逐板日志的旧比赛叙述，请使用完整档案。精简包中的compact比分不能证明未随包保留的具体球路。

已经验证的范围：规则指纹一致；预置检查点load/dump字节一致并深度检查通过；同一合成输入、同seed的full/summary逐板日志hash分别与全包一致；两种日志可重播。该验证不构成新的历史、官方排名或竞技概率认证。

来源、逐项包含/删减清单见MINIMAL_SOURCE_INDEX.json。原始完整档案不要删除。
