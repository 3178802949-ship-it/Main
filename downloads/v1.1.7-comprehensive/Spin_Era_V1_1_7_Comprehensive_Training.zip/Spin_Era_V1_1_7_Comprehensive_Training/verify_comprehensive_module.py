import copy
import json
import sys
from common import ROOT
module = sys.argv[1]
card = json.loads((ROOT/'data/presets_normalized.json').read_text())['starters']['ma18']
if module == 'Game':
    from Game import v118 as Game
    peer=copy.deepcopy(card); peer['player_id']='standalone-peer'
    for mode in ('summary','full'):
        result=Game.play_match([card,peer],117001,'standalone-'+mode,detail_level=mode)
        assert max(result['games_won'])==4 and Game.verify_log(result)
        assert Game.verify_log(Game.compact_log(result))
elif module == 'Card':
    from Card import v118 as Card
    value=Card.public_view(Card.normalize(card))
    assert value['children']==card['children'] and value['P6']==card['P6']
    assert 'style_profile' in value and 'personality_profile' not in value
    assert Card.audit_library()['snapshots_preserving_numeric_traits']==370
elif module == 'Training':
    from Training import v118 as Training
    import career_v116
    state=Training.initialize(card,seed=117001)
    plan=dict(month=0,phase=0,mode='train',body='stamina',technical=[dict(group='read'),dict(group='bh')])
    Training.settle_phase(state,plan,career_v116.environment('club'),'standalone-phase')
    assert Training.load_state(Training.dump_state(state))==state
    assert Training.performance_card(state)['CA']>=0
elif module == 'Area':
    from Area import v118 as Area
    assert Area.validate_calendar(Area.calendar_for_year(2028))['valid']
    assert Area.context_for_date('2028-07-30')['horizon_end']=='2028-07-30'
    try: Area.ensure_date('2028-07-31')
    except ValueError: pass
    else: raise AssertionError('horizon not enforced')
else: raise ValueError(module)
print(module+': independent comprehensive smoke passed')
