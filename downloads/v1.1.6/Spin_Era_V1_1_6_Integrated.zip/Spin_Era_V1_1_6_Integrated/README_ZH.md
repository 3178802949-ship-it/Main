# 旋球年代｜V1.1.6 四模块整合测试包

Game负责比赛，Card负责人物与排名，Training负责每月两次大类训练，Area负责时代、预设与赛程检查。新聊天先读 **OPENING_ZH.md** 和 **docs/AI_HANDOFF_ZH.md**；人类使用说明见 **docs/HUMAN_GUIDE_ZH.md**。

Python 3.11+，运行核心与测试仅需标准库。请在本目录执行：

```bash
python verify_package.py
python self_test.py
python examples/start.py --output saves/my_start
```

查看完整集成演示（包含实际四人淘汰赛、逐场Elo、赛事S-PTS、两次训练及存档）：

```bash
python examples/start.py --demo --output saves/my_demo
```

重新执行发行验收：`python tests/run_release_qa.py`，新收据写入`checks/release_qa/`，发行时的证据保留在`reports/`。重复赛果基准：`python examples/benchmark_game.py`；新训练策略压力检查：`python examples/stress_training.py --workers 4`。后两项会重建相应报告，请在工作副本运行；不会改原始人物库。

各分包自带运行依赖、共享数据和独立测试。无需拼接四份分包即可使用总包；若单独解压某个分包，运行 `python self_test.py --module Game`（或Card、Training、Area）。不要把不同版本的runtime或data覆盖混用。

完整开局卡见 `examples/demo_output/COMPLETE_CARD_MA18.json`，中文全子值卡见 `docs/COMPLETE_CARD_MA18_ZH.md`。START_WORLD是干净开局；DEMO_WORLD仅为验证结算流程的演示世界，不能自动记入新玩家履历。

历史原始资料位于 `data/original/`，规范化后的370张预设位于 `data/presets_normalized.json`。原子值、P6和CA保留，新增发展档案与来源标记；少数超当前身体帽的既有技术保留原值，并限制后续增长。原始档案仍是评估资料，结构适配不代表现实能力认证。

本版不单列九大赛，普通大赛按一般配置；随包赛历是明确标记的沙盒示例。未提供完整史历、官方资格或完整同期世界球员池，默认只能报告样本内排名。

新Game入口逐场隔离进程，可安全并行；低层旧比赛引擎仍不支持共享进程并行。AI应通过WorldSession持久化写入，不得绕过阶段、事件去重与审计。

本版为测试候选。综合问题、已修补丁与后续DLC建议见 `docs/DIAGNOSIS_ZH.md`；功能验收、策略压力检查和历史拟合的状态分别报告，不能相互替代。

维护者可运行 `python build_packages.py --output /tmp/spin-era-packages` 重建四分包和总包，并自动验证每包的干净解压运行。自建存档请放`saves/`，复验输出放`checks/`，不要覆盖随包示例或跨版本覆盖runtime/data。
