# 旋球年代 V1.1.7｜Training 分包

这是测试候选。仅依赖Python 3.11+标准库。入口：from Training import v117 as Training；initialize / settle_phase / performance_card。
本包只含此公开模块及common/runtime/data依赖，其他公开模块目录均不存在。

```bash
python verify_package.py
python self_test.py --module Training
python verify_v117_module.py Training
```

独立模块用于检查与开发。持续生涯应使用Integrated总包的WorldSession，
由统一入口约束时间、训练资源、疲劳、比赛证据、积分和重复结算。
不要拼接不同版本的模块。旧runtime是冻结依赖，不应重复领取旧训练收益。
完整限制、实验结果与叙述要求请阅读总包OPENING_V117_ZH.md及技术报告。
