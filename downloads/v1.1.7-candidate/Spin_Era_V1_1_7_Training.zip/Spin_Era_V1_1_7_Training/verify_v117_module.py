"""New-version standalone smoke without the other public module folders."""
import copy
import json
import sys
from common import ROOT
module = sys.argv[1]
card = json.loads((ROOT/'data/presets_normalized.json').read_text())['starters']['ma18']
if module == 'Game':
    import Game
    peer=copy.deepcopy(card); peer['player_id']='standalone-peer'
    for mode in ('summary','full'):
        result=Game.play_match([card,peer],117001,'standalone-'+mode,ruleset=Game.V117_RULESET,detail_level=mode)
        assert max(result['games_won'])==4 and Game.verify_log(result)
        assert Game.verify_log(Game.compact_log(result))
elif module == 'Card':
    import Card
    import career_v117
    value=career_v117.prepare_card(Card.normalize(card),seed=117001)
    assert value['children']==card['children'] and value['P6']==card['P6']
    assert value['pa_range'][1]-value['pa_range'][0]<=6
elif module == 'Training':
    from Training import v117 as Training
    import career_v116
    state=Training.initialize(card,seed=117001)
    plan=dict(month=0,phase=0,mode='train',body='stamina',technical=[dict(group='read'),dict(group='bh')])
    Training.settle_phase(state,plan,career_v116.environment('club'),'standalone-phase')
    assert Training.load_state(Training.dump_state(state))==state
    assert Training.performance_card(state)['CA']>=0
elif module == 'Area':
    from Area import v117 as Area
    assert Area.validate_calendar(Area.calendar_for_year(2028))['valid']
    assert Area.ensure_date(Area.HORIZON_END)==Area.HORIZON_END
    try: Area.ensure_date('2028-07-31')
    except ValueError: pass
    else: raise AssertionError('horizon not enforced')
else: raise ValueError(module)
print(module+': independent V1.1.7 smoke passed')
