# 2004《旋球年代》→Codex维护交接总入口

这是**原代码 + 历史全过程可得文本/收据 + 修复规格**的一次性交接包；没有声称补丁已集成或回归测试已通过。

阅读顺序：
1. `00_READ_FIRST/CODEX_ONE_SHOT_PROMPT.md`：给Codex的可执行任务。
2. `01_ORIGINAL_ENGINE/Spin_Era_V1_1_7_Comprehensive_UNMODIFIED.zip`：原版综合代码（请先解压，并以此为唯一代码基线）。
3. `02_EXISTING_PATCH/light_v117_anti_shutout_patch_EXPERIMENTAL.py`：旧实验文件，必须审计适配，而不是默认安全替换。
4. `03_2004_CHRONICLE/FULL_YEAR_SIMULATION_SUMMARY.md`、`2004_COLLECTED_ORIGINAL_NARRATIVES.md`、`YEAR_END_FIRST_PERSON.md`：年度进展与第一人称叙述。
5. `04_SAVES_AND_RECEIPTS/2004_YEAR_END_ORIGINAL_HANDOFF.zip`以及其他按序排列的旧档：权威世界状态、原始随机赛果、结算明细、人物库（有旧中间档案含嵌套存档）。
6. `05_SPEC_AND_TESTS/CODEX_ENGINE_PATCH_SPEC.md`：修复方案和验收标准。

2004所有模拟结局已锁定。用户说的2024意指2004，不得误生成2024赛历。原始史料与架空赛事要分层。综合包里`V1.1.7`与`v118`命名混用，应由Codex审查实际入口，不能凭文件名判断使用路径。

注意：部分阶段存档内嵌旧档，归档中会有重复资产；别对相同比赛二次结算。2004聊天中的全部用户可见散文未必全有物理文件，本包提供存在的原始编年文本、逐阶段档案与完整年度概述，不能声称100%复刻不可获取的回复原文。
