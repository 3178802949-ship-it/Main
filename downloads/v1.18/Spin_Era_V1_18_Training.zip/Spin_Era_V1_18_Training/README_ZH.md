# 旋球年代V1.18｜Training分包

入口：`from Training import v1_18 as Training`。仅Python3.11+标准库。
只包含本模块及common/runtime/data依赖；持续生涯与2004存档迁移请使用总包的simulator.WorldSession。
旧默认模块是冻结依赖，不能替代V1.18结算，不要重复领取旧收益。

```bash
python verify_package.py
python self_test.py --module Training
python verify_v1_18_module.py Training
```

本分包不包含2004私有生涯档案。Game的实验反扑默认关闭，身体疲劳修复默认开启；兼容对照可显式physical_fatigue=False。
正式削球/颗粒summary仍有校准限制。详情见总包OPENING_V1_18_ZH.md和设计报告。
