import sys,json,copy,hashlib
from common import ROOT
m=sys.argv[1];c=json.loads((ROOT/'data/presets_normalized.json').read_text())['starters']['ma18']
if m=='Game':
 from Game import v1_18 as G
 d=copy.deepcopy(c);d['player_id']='module-peer'
 for mode in ('summary','full'):
  r=G.play_match([c,d],11899,'module-'+mode,best_of=3,detail_level=mode)
  assert G.verify_log(r) and G.verify_log(G.compact_log(r))
  assert G.replay(G.compact_log(r))['valid']
elif m=='Card':
 from Card import v1_18 as C
 x=C.public_view(C.normalize(c));assert x['children']==c['children'] and 'style_profile'in x and 'personality_profile'not in x
elif m=='Training':
 from Training import v1_18 as T
 import career_v116 as old
 s=T.initialize(c,seed=118);T.award_xp(s,'module-test',{'bh.spin':.25},source_kind='TEST',evidence_hash='0'*64)
 T.settle_phase(s,dict(month=0,phase=0,technical=[dict(group='read'),dict(group='bh')],body='stamina'),old.environment('club'),'module-phase')
 assert T.load_state(T.dump_state(s))==s
elif m=='Area':
 from Area import v1_18 as A
 assert A.validate_calendar(A.calendar_for_year(2028))['valid']
 assert A.HORIZON_END=='2028-07-30'
print(m+': independent V1.18 smoke passed')
